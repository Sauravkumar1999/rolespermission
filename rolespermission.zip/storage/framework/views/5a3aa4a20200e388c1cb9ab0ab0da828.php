<?php $__env->startPush('header'); ?>
    <title>Translation languages</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables-bs5/datatables.bootstrap5.css')); ?>" />
    
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/libs/datatables/datatables-checkboxes-jquery/datatables.checkboxes.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/dt-editor/css/editor.bootstrap5.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main-section'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <?php echo $dataTable->table(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer'); ?>
    <script src="<?php echo e(asset('assets/libs/datatables/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables/forms-editors.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/libs/datatables/dt-editor/js/dataTables.editor.min.js')); ?>">
    </script>
    <script type="text/javascript" src="<?php echo e(asset('assets/libs/datatables/dt-editor/js/editor.bootstrap5.min.js')); ?>">
    </script>
    <?php echo e($dataTable->scripts()); ?>

    <script>
        $(document).ready(function() {
            let languageEditor = window.LaravelDataTables["<?php echo $dataTable->getTableAttribute('id'); ?>-editor"];
            let languageTable = window.LaravelDataTables["<?php echo $dataTable->getTableAttribute('id'); ?>"];

            languageTable.on('click', 'button.editor-delete', function(e) {
                e.preventDefault();
                languageEditor.remove(e.target.closest('tr'), {
                    title: 'Delete this data',
                    message: 'Sure to delete this data',
                    buttons: [{
                            text: 'Close',
                            action: function() {
                                languageEditor.close();
                            }
                        },
                        {
                            text: 'Confirm',
                            action: function() {
                                languageEditor.submit();
                            }
                        }
                    ],
                });
            });

            languageTable.on('click', 'button.editor-edit', function(e) {
                var tdElements = e.target.closest('tr');
                languageEditor.edit(tdElements, {
                    title: 'User Update',
                    buttons: [{
                            text: 'Close',
                            action: function() {
                                languageEditor.close();
                            }
                        },
                        {
                            text: 'Submit',
                            action: function() {
                                languageEditor.submit();
                            }
                        }
                    ]
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\rolespermission\resources\views/dashboard/translation/language.blade.php ENDPATH**/ ?>