<div class="d-inline-block text-nowrap">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.permission.show')): ?>
        <button onclick="" class="btn btn-sm btn-icon editor-permission" data-id="<?php echo e($data->id); ?>">
            <i class="ri-spy-fill text-secondary ri-lg"></i></button>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.edit')): ?>
        <button class="btn btn-sm btn-icon editor-edit"><i class="ri-edit-box-fill text-warning ri-lg"></i></button>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.delete')): ?>
        <button class="btn btn-sm btn-icon editor-delete"><i class="ri-delete-bin-6-fill text-danger ri-lg"></i></button>
    <?php endif; ?>
</div>
<?php /**PATH E:\laragon\www\rolespermission\resources\views/dashboard/users/partials/_action_button_role.blade.php ENDPATH**/ ?>