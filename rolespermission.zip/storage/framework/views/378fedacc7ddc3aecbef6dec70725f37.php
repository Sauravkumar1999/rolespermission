<?php $__env->startPush('header'); ?>
    <title>Permissions</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables-bs5/datatables.bootstrap5.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables-bs5/editor-modal-right.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/libs/datatables/datatables-checkboxes-jquery/datatables.checkboxes.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/datatables/dt-editor/css/editor.bootstrap5.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('main-section'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body px-0">
                    <?php echo $dataTable->table(['class' => 'table table-sm']); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footer'); ?>
    <script src="<?php echo e(asset('assets/libs/datatables/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables/forms-editors.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/libs/datatables/dt-editor/js/dataTables.editor.min.js')); ?>">
    </script>
    <script type="text/javascript" src="<?php echo e(asset('assets/libs/datatables/dt-editor/js/editor.bootstrap5.min.js')); ?>">
    </script>
    <?php echo e($dataTable->scripts()); ?>

    <script>
        $(document).ready(function() {
            let permissionEditor = window.LaravelDataTables["permission-table-editor"];
            let permissionTable = window.LaravelDataTables['permission-table'];

            // Run function on table draw
            permissionTable.on('draw', function() {
                console.log('draw');
            });

            permissionTable.on('click', 'button.editor-delete', function(e) {
                e.preventDefault();
                permissionEditor.remove(e.target.closest('tr'), {
                    title: 'Delete this data',
                    message: 'Sure to delete this data',
                    buttons: [{
                            text: 'Close',
                            action: function() {
                                permissionEditor.close();
                            }
                        },
                        {
                            text: 'Confirm',
                            action: function() {
                                permissionEditor.submit();
                            }
                        }
                    ],
                });
            });

            permissionTable.on('click', 'button.editor-edit', function(e) {
                var tdElements = e.target.closest('tr');
                permissionEditor.edit(tdElements, {
                    title: 'User Update',
                    buttons: [{
                            text: 'Close',
                            action: function() {
                                permissionEditor.close();
                            }
                        },
                        {
                            text: 'Submit',
                            action: function() {
                                permissionEditor.submit();
                            }
                        }
                    ]
                });
            });
            permissionTable.on('click', 'button.editor-permission', function(e) {
                let tdElements = e.target.closest('tr');
                let userId = $(this).data('id');

                let url = "<?php echo e(route('permission.all', ':id')); ?>";
                url = url.replace(':id', userId);

                fetch(url, {
                    header: {
                        "Content-Type": "application/json",
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"
                    }
                }).then(data => data.json()).then(res => {
                    console.log(res);
                })
                console.log(url, userId);
                // permission.all
                $('#modal-permission').modal('show');
            });

            permissionEditor.on('submitSuccess', function(e, json, data) {
                if (json.action === 'remove') {
                    console.log(e, json, data);
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\rolespermission\resources\views/dashboard/users/permission.blade.php ENDPATH**/ ?>