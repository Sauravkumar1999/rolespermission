@extends('layouts.dashboard')
@push('header')
    <title>Files</title>
@endpush
@section('main-section')
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body px-0">
                </div>
            </div>
        </div>
    </div>
@endsection
@push('footer')
@endpush
