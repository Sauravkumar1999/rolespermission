<div class="d-inline-block text-nowrap">
    {{-- @can('permission.edit')
        <button class="btn btn-sm btn-icon editor-edit"><i class="ri-edit-box-fill text-warning ri-lg"></i></button>
    @endcan --}}
    {{-- @can('permission.delete')
        <button class="btn btn-sm btn-icon editor-delete"><i class="ri-delete-bin-6-fill text-danger ri-lg"></i></button>
    @endcan --}}
</div>
