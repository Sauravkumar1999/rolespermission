<div class="d-inline-block text-nowrap">
    <button class="btn btn-sm btn-icon editor-edit"><i class="ri-edit-box-fill text-warning ri-lg"></i></button>
    <button class="btn btn-sm btn-icon editor-delete"><i class="ri-delete-bin-6-fill text-danger ri-lg"></i></button>
</div>
{{-- <div class="btn-group">
    <button class="btn btn-light btn-sm dropdown-toggle hidden-arrow" type="button" id="defaultDropdown"
        data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="ri-more-2-fill"></i>
    </button>
    <ul class="dropdown-menu" aria-labelledby="defaultDropdown" style="">
        <li>
            <a class="dropdown-item editor-permission" data-id="{{ $user->id }}" href="javascript:void(0);">
                <i class="ri-spy-fill text-secondary ri-lg align-middle"></i> <span class="ms-2">Permissions</span>
            </a>
        </li>
        <li><a class="dropdown-item editor-edit" href="javascript:void(0);">
                <i class="ri-edit-box-fill text-warning ri-lg align-middle"></i> <span class="ms-2">Edit</span>
            </a>
        </li>
        <li><a class="dropdown-item editor-delete" href="javascript:void(0);">
                <i class="ri-delete-bin-6-fill text-danger ri-lg align-middle"></i> <span class="ms-2">Delete</span>
            </a>
        </li>
    </ul>
</div> --}}

